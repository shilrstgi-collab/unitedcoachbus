<?php
require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class EmailHelper
{
    public $mail;

    public $MAIL_MAILER = "smtp";
    public $MAIL_HOST = "mail.unitedcoachbus.com";
    public $MAIL_PORT = 465; //465, 587
    public $MAIL_FROM_NAME = "No-Reply";
    public $MAIL_USERNAME = "no-reply@unitedcoachbus.com";
    public $MAIL_PASSWORD = "*rlWBlhZV1u9";
    public $MAIL_ENCRYPTION = "ssl";//PHPMailer::ENCRYPTION_STARTTLS;
    public $MAIL_FROM_ADDRESS = "no-reply@unitedcoachbus.com";
    //public $MAIL_OFFICIAL = "dhyani.deep@gmail.com";
    //public $MAIL_OFFICIAL = "W3mtechnoz@gmail.com";
	public $MAIL_OFFICIAL = "info@unitedcoachbus.com";

    public function __construct()
    {
        try
        {
            $this->mail = new PHPMailer(true);
            //$this->mail->SMTPDebug = SMTP::DEBUG_SERVER; //Enable verbose debug output
            $this->mail->isSMTP(); //Send using SMTP
            $this->mail->Host = $this->MAIL_HOST; //Set the SMTP server to send through
            $this->mail->SMTPAuth = true; //Enable SMTP authentication
            $this->mail->Username = $this->MAIL_USERNAME; //SMTP username
            $this->mail->Password = $this->MAIL_PASSWORD; //SMTP password
            
            $this->mail->SMTPSecure = $this->MAIL_ENCRYPTION;//PHPMailer::ENCRYPTION_SMTPS; //Enable implicit TLS encryption
            //$this->mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; //Enable implicit TLS encryption
           
            $this->mail->Port = $this->MAIL_PORT; //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

            //Recipients
            $this->mail->setFrom($this->MAIL_USERNAME, $this->MAIL_FROM_NAME);
            $this->mail->addAddress($this->MAIL_OFFICIAL); //Add a recipient
            //$this->mail->addAddress('ellen@example.com');               //Name is optional
            //$this->mail->addReplyTo('info@example.com', 'Information');
            //$this->mail->addCC('w3mtechnoz@gmail.com');
            //$this->mail->addBCC('bcc@example.com');

            //Attachments
            //$this->mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
            //$this->mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

            //Content
            $this->mail->isHTML(true); //Set email format to HTML
            //$this->mail->SMTPOptions = array(
            //    'ssl' => array(
            //        'verify_peer' => false,
            //        'verify_peer_name' => false,
            //        'allow_self_signed' => true
            //    )
            //);
            //$this->mail->Subject = 'Here is the subject';
            ///$this->mail->Body    = 'This is the HTML message body <b>in bold!</b>';
            //$this->mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$this->mail->ErrorInfo}";
        }
    }

    public function sendEmail($subject = "", $body = "", $customerEmail = "" )
    {
        try
        {
            $this->mail->Subject = $subject;
            $this->mail->Body = $body;
            $this->mail->AltBody = 'Your mail client must support html emails.';
            //$this->mail->addReplyTo($customerEmail, '');
            //$this->mail->addCC($customerEmail, '');
            //$this->mail->addCC('cc@example.com');
            $this->mail->addBCC($customerEmail);
            $this->mail->send();
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$this->mail->ErrorInfo}";
        }

    }
}
